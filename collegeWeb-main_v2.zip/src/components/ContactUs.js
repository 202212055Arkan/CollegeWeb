import React, { useState } from "react";
import "../CSS/contact.css";
import emailjs from "emailjs-com";

const ContactUs = () => {
  const [userData, setUserData] = useState({
    firstName: "",
    lastName: "",
    phone: "",
    email: "",
    address: "",
    message: "",
  });

  let name, value;

  const postUserData = (event) => {
    name = event.target.name;
    value = event.target.value;
    setUserData({ ...userData, [name]: value });
  };

  // connect with firebase
  function submitData(e) {
    console.log(e.target.firstName.value);
    e.preventDefault();
    emailjs
      .sendForm("service_2c45013", "template_an7s2t6", e.target, "m33PjXRbAPP5zkHcY")
      .then((res) => {
        console.log(res);
      })
      .catch((err) => {
        console.log(err);
      });
  }

  return (
    <div>
      <section className="contactus-section">
        <div className="container">
              <div className="row"
              style={{
                marginLeft:"10%",
            }}>
                <div className="contact-leftside col-12 col-lg-5">
              
                  <figure>
                    <img
                      src="https://res.cloudinary.com/dofftzsmf/image/upload/v1685014572/Contact_us-amico_xt4gyo.png"
                      alt="contatUsImg"
                      className="img-fluid mt-1 ms-10"
                    />
                  </figure>
                </div>

                {/* right side contact form */}
                <div className="contact-rightside mx-auto my-auto col-5 col-lg-5">
                  <form onSubmit={(e) => submitData(e)}>
                    <div className="row">
                    <h1 className="mb-5"
                    style={{
                      fontFamily: "calibri",
                      // marginLeft:"10px",
                      fontSize: "52px",
                      color: "#9867C5",
                      fontWeight: "bold",
                    }}
                  >
                    Connect with Us
                  </h1>

                      <div className="col-12 contact-input-feild ">
                        <input
                          type="text"
                          name="firstName"
                          id=""
                          className="form-control"
                          placeholder="First Name"
                          value={userData.firstName}
                          onChange={postUserData}
                          style={{ padding: "5px" }} // Adjusted padding
                        />
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-12 contact-input-feild ">
                        <input
                          type="text"
                          name="email"
                          id=""
                          className="form-control"
                          placeholder="Email ID"
                          value={userData.email}
                          onChange={postUserData}
                        />
                      </div>
                    </div>
                    <div className="row">
                      <div className="col-12 ">
                        <textarea
                          rows={40}
                          name="message"
                          id=""
                          className="form-textarea"
                          placeholder="Enter Your Message"
                          value={userData.message}
                          onChange={postUserData}
                        />
                      </div>
                    </div>
                    <div style={{marginLeft:"30%"}}>

                    <button  type="submit" className="mt-5 btn btn-style mx-auto my-auto">
                      Submit
                    </button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          
      </section>
    </div>
  );
};

export default ContactUs;
