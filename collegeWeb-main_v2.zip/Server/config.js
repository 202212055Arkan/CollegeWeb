module.exports = {
    'secretKey': '12345-67890-09876-54321',
    // 'mongoUrl': 'mongodb://localhost:27017/conFusion'
    'mongoUrl': 'mongodb://admin:admin@erenyeager-shard-00-00.xpfob.mongodb.net:27017,erenyeager-shard-00-01.xpfob.mongodb.net:27017,erenyeager-shard-00-02.xpfob.mongodb.net:27017/myFirstDatabase?ssl=true&replicaSet=atlas-s243mv-shard-0&authSource=admin&retryWrites=true&w=majority',

}