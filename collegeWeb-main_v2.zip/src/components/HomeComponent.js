import React from 'react';
import CreateCollege from './CreateCollege';
import '../CSS/home.css';
import Search from './Search';
import Footer from './Footer';
import { Container, Row, Col } from 'reactstrap';


function HomeComponent({isAdmin, User,setUser}) {
    let isUser = User && User != undefined && User!= null && User!=""?true:false;
    const backgroundStyle = {
        backgroundImage: `url(https://res.cloudinary.com/dofftzsmf/image/upload/v1684691208/home_background_obxl5b.png)`,
        // backgroundImage: `url(https://res.cloudinary.com/dofftzsmf/image/upload/v1685020985/Screenshot_2023-05-25_184647_g47bh3.png)`,
        
        backgroundSize: 'cover',
        backgroundRepeat: 'no-repeat',
        height: '140vh'
      };
    return (
        <>
        <div className='cta' style={backgroundStyle}>
        <Container>
          <Row className="d-flex justify-content-start">
            <Col>
            <div className='content container row back ms-5'>

        
                <div className='col-8  ml-2  text-left'>
                    
                <h1 className='mt-5 title '> 
                "Explore , Connect  and , Review Your College Experience"
                </h1>       
                <h4 className='text-left mb-4 fs-5'>
                    get any update regarding your college. search your college and follow them to stay upto date
                    <div className='my-1 mt-2'><CreateCollege isUser={isUser} setUser={setUser} /></div>
                    
                </h4>  
        
                </div> 
                
            </div>
            </Col>
          </Row>
        </Container>
        <Footer />
        </div>
       

        </>
        
    );
}

export default HomeComponent;